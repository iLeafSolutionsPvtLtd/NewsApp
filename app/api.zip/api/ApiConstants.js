/* App config for apis
 */
const ApiConstants = {
  BASE_URL:
    "https://newsapi.org/v2/sources?apiKey=3883f1b24cb74b458d717c59a9cbb464",
  FIRST_URL: "https://newsapi.org/v2/everything?",
  LAST_URL:
    "from=2018-09-23&sortBy=publishedAt&apiKey=3883f1b24cb74b458d717c59a9cbb464"
};

export default ApiConstants;
